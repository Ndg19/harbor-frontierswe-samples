"""Experiment driver for 1D heat with optional event-aligned sensitivities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from heat1d.integrator import GridIntegrator, analytic_center, analytic_event_time


@dataclass
class Step:
    kind: str
    value: float | None = None
    threshold: float | None = None


@dataclass
class Experiment:
    steps: list[Step]


class Simulation:
    def __init__(self, alpha: float, *, L: float = 1.0, amplitude: float = 1.0, nx: int = 0):
        self.alpha = float(alpha)
        self.L = float(L)
        self.amplitude = float(amplitude)
        self.nx = int(nx)

    def solve(
        self,
        experiment: Experiment,
        *,
        calculate_sensitivities: bool = False,
        calculate_event_sensitivities: bool = False,
    ) -> dict[str, Any]:
        if calculate_event_sensitivities and not calculate_sensitivities:
            raise ValueError("calculate_event_sensitivities requires calculate_sensitivities")
        t0 = 0.0
        end_times: list[float] = []
        end_centers: list[float] = []
        d_end_times: list[float] = []
        d_end_centers: list[float] = []
        grid_u: np.ndarray | None = None
        grid_du: np.ndarray | None = None
        grid: GridIntegrator | None = None
        if self.nx > 0:
            grid = GridIntegrator(self.alpha, self.L, self.nx)

        for step in experiment.steps:
            if step.kind == "duration":
                dt = float(step.value)
                t1 = t0 + dt
                if grid is None:
                    center = analytic_center(self.alpha, self.amplitude, t1, self.L)
                    d_center = self._danalytic_center(t1) if calculate_sensitivities else 0.0
                else:
                    center, d_center, grid_u, grid_du = grid.advance(
                        t0, dt, calculate_sensitivities, grid_u, grid_du
                    )
                end_times.append(t1)
                end_centers.append(center)
                d_end_times.append(0.0)
                d_end_centers.append(d_center if calculate_sensitivities else 0.0)
                t0 = t1
            elif step.kind == "event":
                thr = float(step.threshold)
                if grid is None:
                    t1 = analytic_event_time(self.alpha, self.amplitude, thr, t0, self.L)
                    center = analytic_center(self.alpha, self.amplitude, t1, self.L)
                    d_t = 0.0
                    d_center = 0.0
                    if calculate_sensitivities:
                        if calculate_event_sensitivities:
                            d_t = self._danalytic_event_time(thr, t0)
                            d_center = 0.0
                        else:
                            d_center = self._danalytic_center(t1)
                else:
                    assert grid is not None
                    t1, center, d_t, d_center, grid_u, grid_du = grid.advance_to_event(
                        t0,
                        thr,
                        calculate_sensitivities,
                        calculate_event_sensitivities,
                        grid_u,
                        grid_du,
                    )
                end_times.append(t1)
                end_centers.append(center)
                d_end_times.append(d_t if calculate_sensitivities else 0.0)
                d_end_centers.append(d_center if calculate_sensitivities else 0.0)
                t0 = t1
            else:
                raise ValueError(f"unknown step kind {step.kind!r}")
        return {
            "values": {"end_times": end_times, "end_centers": end_centers},
            "derivatives": {"end_times": d_end_times, "end_centers": d_end_centers},
        }

    def _danalytic_center(self, t: float) -> float:
        k = np.pi / self.L
        rate = k * k * np.exp(-self.alpha * k * k * t)
        return -self.amplitude * rate * t

    def _danalytic_event_time(self, threshold: float, t0: float) -> float:
        k = np.pi / self.L
        if threshold <= 0 or threshold >= self.amplitude:
            return 0.0
        t_cross = analytic_event_time(self.alpha, self.amplitude, threshold, 0.0, self.L)
        if t_cross <= t0:
            return 0.0
        return t_cross / self.alpha
