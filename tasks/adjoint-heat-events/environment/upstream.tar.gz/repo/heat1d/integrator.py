"""Analytic sine-mode helpers and explicit grid integrator."""

from __future__ import annotations

import math

import numpy as np


def analytic_center(alpha: float, amplitude: float, t: float, L: float = 1.0) -> float:
    k = math.pi / L
    return amplitude * math.sin(k * (L / 2.0)) * math.exp(-alpha * k * k * t)


def analytic_event_time(
    alpha: float,
    amplitude: float,
    threshold: float,
    t0: float = 0.0,
    L: float = 1.0,
) -> float:
    k = math.pi / L
    if threshold <= 0 or threshold >= amplitude:
        raise ValueError("threshold outside (0, amplitude)")
    t_cross = -math.log(threshold / amplitude) / (alpha * k * k)
    return max(float(t0), t_cross)


class GridIntegrator:
    def __init__(self, alpha: float, L: float, nx: int):
        self.alpha = float(alpha)
        self.L = float(L)
        self.nx = int(nx)
        self.dx = self.L / (self.nx - 1)
        self.x = np.linspace(0.0, self.L, self.nx)
        self.center_index = self.nx // 2
        self._dt = 0.4 * self.dx * self.dx / max(self.alpha, 1e-9)

    def initial_state(self) -> np.ndarray:
        return np.sin(math.pi * self.x / self.L)

    def advance(
        self,
        t0: float,
        duration: float,
        sens: bool,
        u0: np.ndarray | None = None,
        d_u0: np.ndarray | None = None,
    ) -> tuple[float, float, np.ndarray, np.ndarray | None]:
        u = self.initial_state().copy() if u0 is None else u0.copy()
        d_u_dalpha = (
            np.zeros_like(u)
            if sens and d_u0 is None
            else (None if not sens else d_u0.copy())
        )
        t = t0
        target = t0 + duration
        while t + self._dt <= target + 1e-15:
            u, d_u_dalpha = self._step(u, d_u_dalpha, sens)
            t += self._dt
        remaining = target - t
        if remaining > 1e-12:
            u, d_u_dalpha = self._step(u, d_u_dalpha, sens, scale=remaining / self._dt)
            t = target
        center = float(u[self.center_index])
        d_center = float(d_u_dalpha[self.center_index]) if sens and d_u_dalpha is not None else 0.0
        return center, d_center, u, d_u_dalpha

    def advance_to_event(
        self,
        t0: float,
        threshold: float,
        sens: bool,
        event_sens: bool,
        u0: np.ndarray | None = None,
        d_u0: np.ndarray | None = None,
    ) -> tuple[float, float, float, float, np.ndarray, np.ndarray | None]:
        u = self.initial_state().copy() if u0 is None else u0.copy()
        d_u_dalpha = (
            np.zeros_like(u)
            if sens and d_u0 is None
            else (None if not sens else d_u0.copy())
        )
        t = t0
        if float(u[self.center_index]) >= threshold:
            d_t = 0.0
            d_center = float(d_u_dalpha[self.center_index]) if sens and d_u_dalpha is not None else 0.0
            if sens and event_sens:
                d_center = 0.0
            return t, float(u[self.center_index]), d_t, d_center, u, d_u_dalpha
        while float(u[self.center_index]) < threshold:
            u, d_u_dalpha = self._step(u, d_u_dalpha, sens)
            t += self._dt
            if t > t0 + 1000:
                raise RuntimeError("event time search exceeded safety limit")
        center = float(u[self.center_index])
        if not sens:
            return t, center, 0.0, 0.0, u, d_u_dalpha
        if event_sens:
            d_t = 0.0  # stub
            return t, center, d_t, 0.0, u, d_u_dalpha
        d_center = float(d_u_dalpha[self.center_index])
        return t, center, 0.0, d_center, u, d_u_dalpha

    def _step(
        self,
        u: np.ndarray,
        d_u_dalpha: np.ndarray | None,
        sens: bool,
        scale: float = 1.0,
    ) -> tuple[np.ndarray, np.ndarray | None]:
        dt = self._dt * scale
        lap = self._laplacian(u)
        u_new = u + dt * self.alpha * lap
        if not sens:
            return u_new, None
        assert d_u_dalpha is not None
        lap_d = self._laplacian(d_u_dalpha)
        d_new = d_u_dalpha + dt * (lap + self.alpha * lap_d)
        return u_new, d_new

    def _laplacian(self, u: np.ndarray) -> np.ndarray:
        out = np.zeros_like(u)
        out[1:-1] = (u[:-2] - 2.0 * u[1:-1] + u[2:]) / (self.dx * self.dx)
        return out

    def _event_time_sensitivity(
        self, u: np.ndarray, d_u_dalpha: np.ndarray, threshold: float
    ) -> float:
        idx = self.center_index
        du_dt = self.alpha * self._laplacian(u)[idx]
        dg_dalpha = float(d_u_dalpha[idx])
        if abs(du_dt) < 1e-12:
            return 0.0
        return -(dg_dalpha) / du_dt
