"""Slotted CBOR framing v1 (stub — not implemented)."""

from __future__ import annotations

from pathlib import Path


class FramingError(Exception):
    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code


def encode_stream(manifest_path: Path, output_path: Path) -> None:
    raise NotImplementedError("framing encode not implemented in upstream stub")


def decode_stream(input_path: Path, output_dir: Path) -> None:
    raise NotImplementedError("framing decode not implemented in upstream stub")


def stream_decode_lines(input_path: Path) -> list[str]:
    raise NotImplementedError("framing stream decode not implemented in upstream stub")
