from slotted_cbor.cbor import decode_map, encode_map
__all__ = ["encode_map", "decode_map"]
