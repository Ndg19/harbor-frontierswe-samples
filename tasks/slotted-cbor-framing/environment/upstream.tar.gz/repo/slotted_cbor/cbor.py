"""Minimal CBOR subset: maps with text keys and byte/text values."""

from __future__ import annotations


def _encode_text(value: str) -> bytes:
    data = value.encode("utf-8")
    return _encode_bytes_header(0x60, data) + data


def _encode_bytes_header(major_base: int, data: bytes) -> bytes:
    n = len(data)
    if n < 24:
        return bytes([major_base + n])
    if n < 256:
        return bytes([major_base + 24, n])
    raise ValueError("value too long for subset")


def encode_bytes(value: bytes) -> bytes:
    return _encode_bytes_header(0x40, value) + value


def encode_map(items: dict[str, str | bytes]) -> bytes:
    out = bytes([0xA0 + len(items)])
    for key in sorted(items):
        out += _encode_text(key)
        val = items[key]
        out += _encode_text(val) if isinstance(val, str) else encode_bytes(val)
    return out


def _read_length(data: bytes, idx: int, base: int) -> tuple[int, int]:
    info = data[idx] & 0x1F
    idx += 1
    if info < 24:
        return info, idx
    if info == 24:
        return data[idx], idx + 1
    raise ValueError("unsupported CBOR length")


def decode_map(data: bytes) -> dict[str, str | bytes]:
    if not data or (data[0] & 0xE0) != 0xA0:
        raise ValueError("expected map")
    count, idx = _read_length(data, 0, 0xA0)
    out: dict[str, str | bytes] = {}
    for _ in range(count):
        if (data[idx] & 0xE0) != 0x60:
            raise ValueError("expected text key")
        klen, idx = _read_length(data, idx, 0x60)
        key = data[idx : idx + klen].decode("utf-8")
        idx += klen
        major = data[idx] & 0xE0
        if major == 0x60:
            vlen, idx = _read_length(data, idx, 0x60)
            out[key] = data[idx : idx + vlen].decode("utf-8")
            idx += vlen
        elif major == 0x40:
            vlen, idx = _read_length(data, idx, 0x40)
            out[key] = data[idx : idx + vlen]
            idx += vlen
        else:
            raise ValueError("unsupported value type")
    if idx != len(data):
        raise ValueError("trailing cbor bytes")
    return out
