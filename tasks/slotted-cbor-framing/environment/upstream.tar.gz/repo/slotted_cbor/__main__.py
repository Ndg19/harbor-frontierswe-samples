from __future__ import annotations

import sys

print("slotted_cbor CLI unavailable in upstream stub", file=sys.stderr)
raise SystemExit(1)
